int initialize(int *array, int length);
int returnMin(int *array, int length, int min);
